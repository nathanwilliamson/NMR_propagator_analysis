%Test fast fourier transform of q-space data for diffusion and flow (from Bloch-Torrey) 
% to find propagator
%simulates data with the possibility of a g offset, like we do in our
%experiments.
% Nathan Williamson 10/18/2017
close all
clear all
clc
%% define parameters
delta = 0.001   ;            % delta
Delta = 1    ;           % Delta
Gamma  = 2.6752219E8;          % Gammamagnetic ratio [rad S^-1 T^-1]
gstart = 0.000;               % gradient start. We assume this value to be 0 in the F.T.
gmax = .1;                % gradient end
gnum = 61;              % number of gradient pts. An odd number will lead to an even number for the FT, and vice-versa, but this doesn't seem to matter. We assume linear spacing in the FT.    
g = linspace(gstart,gmax,gnum); %gradient vecor
q = g *Gamma*delta/ (2*pi) ;      % q-space. q needs to be in units of [1/m], rather than [rad/m] for the the fast fourier transform. a cycle in the fft is 0 to 1. Note the units are [radians/m] for q-space in callaghan, as well as for the stejskal tanner relation. In the S.T. Relation it needs to be rad/s because by euler's formula we are really talking about rotations in radians. 
b_=Gamma^2.*(g.^2).*delta^2 .* (Delta-delta/3);

%% simulate data based on bloch torrey diffusion and flow
v = 0.0001;                   % mean velocity [m/s]
D = 2E-9;                    % Diffusion coefficient [m^2/s] 
E = exp(1i*(2*pi*q)*v*Delta-(2*pi*q).^2*D*(Delta-delta/3)); % multiply q by 2*pi because In the S.T. relation it needs to be rad/s because by euler's formula we are really talking about rotations in radians.  
%E = E + randn(1,gnum)*abs(E(1))/50;                                


%% For FT 

 E = E.*exp(-1i*angle(E(1)));        % phase data so that the first E(q) point is entirely real.     
 y=[-fliplr(q(2:end)),q(1:end-1)];
 xdim = length(y);                  % number of points
 E_ft=[conj(fliplr(E(2:end))),E(1:end-1)];   % we do the conjugate of E for negative q because the imaginary signal has opposite sign after reflection.

% % X = (1:xdim) - xdim/2;      % x-domain variable
%  xshift = 0;                  % not necessary since q-space is always max at q=0, 
%  y = X - (xshift+1);         % zero in the middle of the x-domain



% Fourier Transform of A to give spectrum
%
%            put E center at edges
%                +---------+
%                v         v
P = fftshift(fft(fftshift(E_ft),xdim));
%   ^                             ^
%   +-----------------------------+
%      put FT(E) center at edges

% make inverse q vector

qinv = ((1:xdim) - xdim/2)/(y(end)-y(1));
dqinv = qinv(2) - qinv(1);

% plot q-space data

figure
subplot(2,1,1) 
plot(y,real(E_ft),'k')
hold on
plot(y,imag(E_ft),'r')
title('E(q) ','FontSize',14);
xlabel('q','FontSize',14)

% Plot the real, imag and mag data for the FT (w-domain) data B

subplot(2,1,2) 
%plot(w-dw,real(B),w-dw,abs(B),w-dw,imag(B))
plot(qinv-dqinv,real(P),'b',qinv-dqinv,imag(P),'r',qinv-dqinv,abs(P),'g')


title('P(q)','FontSize',14);
xlabel('1/q','FontSize',14)

axis([min(qinv) max(qinv) max(abs(P))*-1.1 max(abs(P))*1.1])


%% plot a gaussian centered about the average displacement

P_gaussian=(4*pi*D*Delta)^(-1/2).*exp(-(qinv-(v*Delta)).^2./(4*D*Delta));
P_g_norm=P_gaussian/max(P_gaussian)*max(abs(P)); %normlaizing for plot
hold on
plot(qinv,P_g_norm,':');
hold off

MSD=sum(qinv.^2.*abs(P))/sum(abs(P));
D_MSD=MSD/(2*Delta);

% Dfwhm=fwhm(f,P1)

vector=log(abs(E(1:7)'/abs(E(1))));
b=b_(1:7)';
D_fit=vector'*b/(b'*b); % Vector calculus fit of the slope. Think about this.
% figure
% Sinv=ifft(Y);
% plot(q,Sinv) 
% title('ifft of S(t)')
% xlabel('t (Hz)')
% ylabel('P1(t)')

E_=E.';
q=q.'*2*pi;
T = angle(E_);
v_T = T'*q/(q'*q) / Delta;
figure; plot(q,T/Delta,'*')
hold on
plot(q,v_T*q)